import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowLeft, ShieldCheck } from "lucide-react";

export default function Terms() {
  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 font-sans py-12 px-4">
      <div className="container max-w-3xl mx-auto bg-white p-8 md:p-12 rounded-2xl border border-slate-200 shadow-sm space-y-6">
        <Link href="/">
          <Button variant="ghost" className="gap-2 text-slate-600 hover:text-slate-900 mb-4">
            <ArrowLeft className="h-4 w-4" /> Voltar para a Loja
          </Button>
        </Link>

        <div className="border-b border-slate-200 pb-6">
          <h1 className="text-3xl font-black text-slate-900 tracking-tight">Termos de Uso</h1>
          <p className="text-xs text-slate-500 mt-2">Última atualização: 23 de Maio de 2026</p>
        </div>

        <div className="space-y-6 text-sm sm:text-base leading-relaxed text-slate-600">
          <section className="space-y-3">
            <h2 className="text-xl font-bold text-slate-900">1. Termos Gerais</h2>
            <p>
              Ao acessar e utilizar este website para agendar seu pedido do Óculos Inteligente 2V Pro, você concorda em cumprir e estar vinculado aos seguintes Termos de Uso. Se você não concordar com qualquer parte destes termos, por favor, não utilize nossos serviços de agendamento.
            </p>
          </section>

          <section className="space-y-3">
            <h2 className="text-xl font-bold text-slate-900">2. Descrição do Produto e Isenção de Responsabilidade Médica</h2>
            <p>
              O Óculos Inteligente 2V Pro é um produto óptico com tecnologia de foco dinâmico adaptável, projetado para auxiliar no foco visual de perto e de longe em graus leves e moderados (de até +3.50 de grau).
            </p>
            <p className="bg-amber-50 border-l-4 border-amber-500 p-4 text-amber-900 text-xs sm:text-sm rounded-r-lg font-medium">
              ⚠️ <strong>AVISO DE SAÚDE:</strong> Este produto não substitui exames oftalmológicos regulares, prescrições médicas personalizadas ou diagnósticos de patologias oculares complexas, como astigmatismo alto ou condições graves de visão. Recomendamos fortemente a consulta regular com um oftalmologista para avaliação da sua saúde visual.
            </p>
          </section>

          <section className="space-y-3">
            <h2 className="text-xl font-bold text-slate-900">3. Processo de Agendamento e Pagamento na Entrega (COD)</h2>
            <p>
              Nossa modalidade de venda é baseada no sistema de <strong>Pagamento na Entrega (Cash on Delivery - COD)</strong>. Isso significa que:
            </p>
            <ul className="list-disc list-inside pl-4 space-y-2 text-xs sm:text-sm">
              <li>O agendamento realizado no site não exige qualquer pagamento antecipado.</li>
              <li>O cliente se compromete a fornecer dados corretos de entrega (nome, endereço e telefone ativo com WhatsApp).</li>
              <li>O cliente assume o compromisso de ter um responsável maior de idade presente no endereço indicado para receber o produto e efetuar o pagamento ao entregador.</li>
              <li>O pagamento pode ser efetuado em dinheiro, PIX ou cartão de crédito (com opção de parcelamento) diretamente à transportadora no ato da entrega.</li>
            </ul>
          </section>

          <section className="space-y-3">
            <h2 className="text-xl font-bold text-slate-900">4. Política de Envio e Logística</h2>
            <p>
              Oferecemos frete grátis para todas as regiões cobertas pelo nosso serviço no Brasil. Os prazos de entrega informados são estimativas baseadas na logística das transportadoras parceiras. Entraremos em contato via WhatsApp para confirmar o agendamento antes do envio. Reservamo-nos o direito de cancelar agendamentos cujos dados de contato se mostrem inválidos ou inacessíveis.
            </p>
          </section>

          <section className="space-y-3">
            <h2 className="text-xl font-bold text-slate-900">5. Política de Garantia e Devolução</h2>
            <p>
              Garantimos o direito de arrependimento e satisfação no prazo de 30 dias após o recebimento do produto, conforme o Código de Defesa do Consumidor brasileiro. Caso não se adapte ao óculos, você poderá solicitar a devolução e o reembolso total do valor pago diretamente através de nossos canais de atendimento, sem qualquer burocracia.
            </p>
          </section>

          <section className="space-y-3">
            <h2 className="text-xl font-bold text-slate-900">6. Limitação de Responsabilidade</h2>
            <p>
              Não nos responsabilizamos por uso inadequado do produto ou por expectativas irreais não condizentes com a tecnologia descrita de forma transparente neste site. O uso do óculos deve seguir as orientações básicas de adaptação e uso diário.
            </p>
          </section>
        </div>

        <div className="border-t border-slate-200 pt-6 flex flex-col sm:flex-row justify-between items-center gap-4 text-xs text-slate-500">
          <span className="flex items-center gap-1.5 text-emerald-600 font-bold">
            <ShieldCheck className="h-4 w-4" /> COMPLIANCE GOOGLE ADS GARANTIDO
          </span>
          <span>ÓCULOS 2V PRO® - CNPJ: 37.273.558/0001-50</span>
        </div>
      </div>
    </div>
  );
}
