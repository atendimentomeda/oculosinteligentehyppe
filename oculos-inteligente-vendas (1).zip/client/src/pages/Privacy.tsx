import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowLeft, ShieldCheck } from "lucide-react";

export default function Privacy() {
  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 font-sans py-12 px-4">
      <div className="container max-w-3xl mx-auto bg-white p-8 md:p-12 rounded-2xl border border-slate-200 shadow-sm space-y-6">
        <Link href="/">
          <Button variant="ghost" className="gap-2 text-slate-600 hover:text-slate-900 mb-4">
            <ArrowLeft className="h-4 w-4" /> Voltar para a Loja
          </Button>
        </Link>

        <div className="border-b border-slate-200 pb-6">
          <h1 className="text-3xl font-black text-slate-900 tracking-tight">Política de Privacidade</h1>
          <p className="text-xs text-slate-500 mt-2">Última atualização: 23 de Maio de 2026</p>
        </div>

        <div className="space-y-6 text-sm sm:text-base leading-relaxed text-slate-600">
          <section className="space-y-3">
            <h2 className="text-xl font-bold text-slate-900">1. Compromisso com a Privacidade</h2>
            <p>
              Sua privacidade é de extrema importância para nós. Esta Política de Privacidade descreve como coletamos, usamos, armazenamos e protegemos suas informações pessoais quando você utiliza nosso site para agendar o pedido do Óculos Inteligente 2V Pro. Operamos em total conformidade com a Lei Geral de Proteção de Dados (LGPD) no Brasil.
            </p>
          </section>

          <section className="space-y-3">
            <h2 className="text-xl font-bold text-slate-900">2. Coleta de Informações Pessoais</h2>
            <p>
              Coletamos apenas as informações estritamente necessárias para processar e realizar a entrega do seu pedido na modalidade de Pagamento na Entrega (COD):
            </p>
            <ul className="list-disc list-inside pl-4 space-y-1.5 text-xs sm:text-sm">
              <li><strong>Dados de Contato:</strong> Nome completo, número de telefone com WhatsApp e endereço de e-mail.</li>
              <li><strong>Dados de Entrega:</strong> Endereço residencial ou comercial completo (rua, número, complemento, bairro, cidade, estado e CEP).</li>
              <li><strong>Dados Fiscais:</strong> CPF (solicitado exclusivamente para a emissão da nota fiscal de transporte exigida por lei pelas transportadoras parceiras).</li>
            </ul>
            <p className="text-emerald-600 font-medium text-xs sm:text-sm">
              🔒 <strong>Nota de Segurança:</strong> Não coletamos nem armazenamos quaisquer dados de cartão de crédito, senhas ou dados bancários em nosso site, visto que o pagamento é realizado de forma física e direta no momento da entrega do produto.
            </p>
          </section>

          <section className="space-y-3">
            <h2 className="text-xl font-bold text-slate-900">3. Uso das Informações</h2>
            <p>
              As informações coletadas são utilizadas exclusivamente para as seguintes finalidades:
            </p>
            <ul className="list-disc list-inside pl-4 space-y-1 text-xs sm:text-sm">
              <li>Processar, faturar e despachar o seu agendamento de óculos.</li>
              <li>Entrar em contato via WhatsApp ou ligação telefônica para confirmar os dados de entrega e o melhor dia/horário de recebimento.</li>
              <li>Prevenir fraudes de agendamento e garantir a integridade do serviço de entrega.</li>
              <li>Prestar suporte ao cliente pós-venda, incluindo acionamento de garantia ou devoluções.</li>
            </ul>
          </section>

          <section className="space-y-3">
            <h2 className="text-xl font-bold text-slate-900">4. Compartilhamento de Dados com Terceiros</h2>
            <p>
              Não vendemos, alugamos ou compartilhamos seus dados pessoais com terceiros para fins de marketing. Seus dados são compartilhados única e exclusivamente com as <strong>empresas transportadoras parceiras</strong> responsáveis pela entrega física do produto e coleta do pagamento, estritamente na medida do necessário para a conclusão da entrega.
            </p>
          </section>

          <section className="space-y-3">
            <h2 className="text-xl font-bold text-slate-900">5. Segurança dos Dados</h2>
            <p>
              Implementamos medidas de segurança técnicas e organizacionais adequadas para proteger seus dados pessoais contra perda, uso não autorizado ou acesso indevido. Nosso site utiliza criptografia <strong>SSL (Secure Socket Layer)</strong> de última geração para garantir que todos os dados transmitidos sejam totalmente confidenciais e protegidos.
            </p>
          </section>

          <section className="space-y-3">
            <h2 className="text-xl font-bold text-slate-900">6. Direitos do Usuário</h2>
            <p>
              Você possui total controle sobre seus dados pessoais. De acordo com a LGPD, você tem o direito de solicitar a qualquer momento a confirmação da existência de tratamento, acesso aos dados, correção de dados incompletos ou a exclusão definitiva de suas informações de nossa base de dados ativa. Para exercer esses direitos, basta entrar em contato com o nosso canal de suporte.
            </p>
          </section>
        </div>

        <div className="border-t border-slate-200 pt-6 flex flex-col sm:flex-row justify-between items-center gap-4 text-xs text-slate-500">
          <span className="flex items-center gap-1.5 text-emerald-600 font-bold">
            <ShieldCheck className="h-4 w-4" /> COMPLIANCE GOOGLE ADS GARANTIDO
          </span>
          <span>ÓCULOS 2V PRO® - CNPJ: 37.273.558/0001-50</span>
        </div>
      </div>
    </div>
  );
}
