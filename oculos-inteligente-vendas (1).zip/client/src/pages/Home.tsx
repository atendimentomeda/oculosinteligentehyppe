import { useState, useEffect, useRef } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";
import { 
  Check, 
  ShieldCheck, 
  Truck, 
  Clock, 
  Star, 
  ThumbsUp, 
  Play, 
  Pause, 
  Volume2, 
  VolumeX, 
  AlertTriangle, 
  Smartphone, 
  MapPin, 
  CreditCard, 
  ArrowRight,
  Sparkles,
  Eye,
  ShieldAlert
} from "lucide-react";

// Images including original product, downloaded S3, and user-provided physical & comparison images
const IMAGES = {
  original: "/manus-storage/oculos_original_e68e25d1.png",
  physical_demo: "/manus-storage/flexibilidade_665b4aca.gif", // GIF showing frame flexibility
  driving_compare: "/manus-storage/pasted_file_FWCIN7_image_27bd004d.png", // Before/After driving comparison
};

// All 4 video URLs provided by user - REORDERED: Female testimonials first, then male.
// 0204-1-3.mp4 and 0204-1-4.mp4 are female testimonials, 0204-1-1.mp4 and 0204-1-2.mp4 are male.
const VIDEOS = [
  { url: "https://oculos2v-pro.store/wp-content/uploads/2026/02/0204-1-3.mp4", title: "Depoimento de Maria Helena", desc: "Uso diário para leitura e costura" },
  { url: "https://oculos2v-pro.store/wp-content/uploads/2026/02/0204-1-4.mp4", title: "Depoimento de Alzira Souza", desc: "Ajuste dinâmico e conforto imediato" },
  { url: "https://oculos2v-pro.store/wp-content/uploads/2026/02/0204-1-1.mp4", title: "Depoimento de João Pedro", desc: "Uso para dirigir e leitura" },
  { url: "https://oculos2v-pro.store/wp-content/uploads/2026/02/0204-1-2.mp4", title: "Depoimento de Carlos Eduardo", desc: "Foco perfeito de longe e de perto" }
];

// Offers structured according to user request
const OFFERS = [
  {
    id: "1-unit",
    title: "Leve 1 Unidade",
    subtitle: "Óculos Inteligente 2V Pro",
    price: "R$ 159,90",
    installment: "Ou em até 12x no cartão",
    discount: "Economize 40%",
    link: "http://app.hyppe.com.br/venda-multiplos?produto=NDQ%3D&afiliado=NDc3Mw%3D%3D&oferta=MTY5Mg%3D%3D",
    popular: false,
    badge: "OPÇÃO BÁSICA",
    features: [
      "1x Óculos Inteligente Original",
      "Estojo de Proteção de Brinde",
      "Flanela de Limpeza Especial",
      "Frete Grátis para todo o Brasil",
      "Pague Apenas na Entrega"
    ]
  },
  {
    id: "2-units",
    title: "Leve 2 Unidades",
    subtitle: "Óculos Inteligente 2V Pro",
    price: "R$ 189,90",
    installment: "Ou em até 12x no cartão",
    discount: "Economize 60% (Recomendado)",
    link: "http://app.hyppe.com.br/venda-multiplos?produto=NDQ%3D&afiliado=NDc3Mw%3D%3D&oferta=MTQ2MQ%3D%3D",
    popular: true,
    badge: "MAIS VENDIDO E RECOMENDADO",
    features: [
      "2x Óculos Inteligentes Originais (Deixe um em casa e outro no carro)",
      "2x Estojos de Proteção de Brinde",
      "2x Flanelas de Limpeza Especial",
      "Frete Grátis para todo o Brasil",
      "Pague Apenas na Entrega",
      "Garantia de Satisfação de 30 dias"
    ]
  },
  {
    id: "3-units",
    title: "Leve 3 Unidades",
    subtitle: "Óculos Inteligente 2V Pro",
    price: "R$ 257,90",
    installment: "Ou em até 12x no cartão",
    discount: "Economize 70%",
    link: "http://app.hyppe.com.br/venda-multiplos?produto=NDQ%3D&afiliado=NDc3Mw%3D%3D&oferta=MTY5My%3D%3D",
    popular: false,
    badge: "KIT FAMÍLIA",
    features: [
      "3x Óculos Inteligentes Originais (Presenteie quem você ama)",
      "3x Estojos de Proteção de Brinde",
      "3x Flanelas de Limpeza Especial",
      "Frete Grátis para todo o Brasil",
      "Pague Apenas na Entrega",
      "Garantia de Satisfação de 30 dias"
    ]
  }
];

// Testimonials
const TESTIMONIALS = [
  {
    name: "Maria A.",
    location: "São Paulo/SP",
    text: "Sofro de hipermetropia e agora consigo ler e enxergar longe com clareza. O óculos faz o ajuste automaticamente, sem esforço, e não sinto mais fadiga.",
    likes: 164,
    time: "9min",
    verified: "Compradora verificada"
  },
  {
    name: "Camila R.",
    location: "Recife/PE",
    text: "Trabalho horas no computador e leio bastante à noite. O óculos se ajusta automaticamente e evita o desconforto nos olhos. Além disso, paguei só quando recebi em casa.",
    likes: 97,
    time: "18min",
    verified: "Compra confirmada"
  },
  {
    name: "João P.",
    location: "Brasília/DF",
    text: "Tenho miopia leve e o óculos se ajusta sozinho quando olho perto ou longe. Consigo trabalhar e dirigir sem precisar trocar de armação.",
    likes: 81,
    time: "27min",
    verified: "Comprador verificado"
  },
  {
    name: "Carlos E.",
    location: "Curitiba/PR",
    text: "Tenho vista cansada e ficava difícil ler de perto. Com esse óculos, a visão se adapta sozinha e consigo usar tanto no computador quanto em livros sem dores de cabeça.",
    likes: 55,
    time: "41min",
    verified: "Compra confirmada"
  },
  {
    name: "Rodrigo M.",
    location: "Manaus/AM",
    text: "Uso para dirigir e também no celular. Ele se ajusta sozinho e a visão fica sempre nítida. Gostei muito da praticidade de pagar apenas na entrega.",
    likes: 62,
    time: "59min",
    verified: "Comprador verificado"
  }
];

export default function Home() {
  const [timeLeft, setTimeLeft] = useState({ hours: 2, minutes: 47, seconds: 35 });
  const [mutedVideos, setMutedVideos] = useState<boolean[]>([true, true, true, true]);
  const offersSectionRef = useRef<HTMLDivElement>(null);

  // Countdown timer for urgency
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
        } else if (prev.hours > 0) {
          return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
        } else {
          clearInterval(timer);
          return prev;
        }
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatNumber = (num: number) => num.toString().padStart(2, "0");

  const scrollToOffers = () => {
    offersSectionRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const toggleMuteVideo = (index: number) => {
    setMutedVideos(prev => {
      const updated = [...prev];
      updated[index] = !updated[index];
      return updated;
    });
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans antialiased text-base sm:text-lg">
      {/* Top Banner - Highly visible, clean background */}
      <div className="bg-amber-400 text-slate-950 py-3 px-4 text-center font-bold text-sm sm:text-base flex flex-wrap justify-center items-center gap-x-6 gap-y-1.5 shadow-sm sticky top-0 z-50">
        <span className="flex items-center gap-2">
          <Truck className="h-5 w-5 shrink-0" /> 🚚 FRETE GRÁTIS HOJE PARA TODO O BRASIL!
        </span>
        <span className="hidden md:inline">|</span>
        <span className="flex items-center gap-2">
          <ShieldCheck className="h-5 w-5 shrink-0" /> PAGAMENTO SOMENTE NA ENTREGA (COD)
        </span>
        <span className="hidden md:inline">|</span>
        <span className="flex items-center gap-2 font-extrabold">
          ⏱️ Oferta por tempo limitado: {formatNumber(timeLeft.hours)}h {formatNumber(timeLeft.minutes)}m {formatNumber(timeLeft.seconds)}s
        </span>
      </div>

      {/* Hero Section - Clean Light Theme, highly accessible for 35-65+ age group */}
      <header className="relative bg-white py-10 md:py-16 border-b border-slate-200 overflow-hidden">
        <div className="container max-w-6xl mx-auto px-4 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
            
            {/* Left Content - Large, highly legible fonts */}
            <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
              <div className="inline-flex items-center gap-2 bg-blue-50 border border-blue-200 text-blue-800 font-bold py-1.5 px-4 rounded-full text-xs sm:text-sm uppercase tracking-wide">
                <Sparkles className="h-4 w-4 text-blue-600 shrink-0" /> Tecnologia Inteligente Original
              </div>
              
              <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-black text-slate-900 tracking-tight leading-tight">
                Óculos Inteligente <span className="text-blue-600">2V Pro Original!</span>
              </h1>
              
              <h2 className="text-xl sm:text-2xl md:text-3xl font-bold text-slate-800 leading-snug">
                Se adapta ao seu grau de visão de forma automática!
              </h2>
              
              <p className="text-base sm:text-lg md:text-xl text-slate-600 max-w-2xl mx-auto lg:mx-0 font-medium leading-relaxed">
                Enxergue perfeitamente de perto e de longe — sem precisar trocar de óculos ou gastar fortunas com consultas. Pronto para uso imediato!
              </p>

              {/* Bullet Points with large icons and clear text */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-lg mx-auto lg:mx-0 text-left pt-2">
                {[
                  "Foco Inteligente Perto e Longe",
                  "Sem necessidade de receita médica",
                  "Armação leve, flexível e unissex",
                  "Serve confortavelmente em qualquer rosto"
                ].map((item, i) => (
                  <div key={i} className="flex items-center gap-3 text-slate-800 font-bold">
                    <div className="h-6 w-6 rounded-full bg-emerald-100 flex items-center justify-center shrink-0">
                      <Check className="h-4 w-4 text-emerald-600 font-black" />
                    </div>
                    <span className="text-sm sm:text-base">{item}</span>
                  </div>
                ))}
              </div>

              {/* Large, Easy-to-click GREEN CTA button for seniors */}
              <div className="pt-4 flex flex-col sm:flex-row justify-center lg:justify-start items-center gap-4">
                <Button 
                  onClick={scrollToOffers}
                  className="w-full sm:w-auto bg-emerald-600 hover:bg-emerald-700 text-white font-black text-lg sm:text-xl py-7 px-10 rounded-xl shadow-lg shadow-emerald-600/20 transition-all duration-150 active:scale-[0.97] uppercase tracking-wide flex items-center justify-center gap-3"
                >
                  <span>AGENDAR PEDIDO</span>
                  <ArrowRight className="h-6 w-6 shrink-0" />
                </Button>
                <div className="text-center lg:text-left">
                  <div className="flex items-center justify-center lg:justify-start gap-1 text-amber-500">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="h-5 w-5 fill-current" />
                    ))}
                    <span className="text-slate-900 font-black ml-1 text-base">4.9/5</span>
                  </div>
                  <p className="text-xs sm:text-sm text-slate-500 font-semibold mt-0.5">Mais de 14.820 clientes satisfeitos no Brasil</p>
                </div>
              </div>

              {/* Trust badging */}
              <div className="pt-4 flex flex-wrap justify-center lg:justify-start gap-5 text-xs sm:text-sm text-slate-500 border-t border-slate-200 font-medium">
                <span className="flex items-center gap-1.5 text-slate-700"><ShieldCheck className="h-4.5 w-4.5 text-emerald-600" /> Compra Segura SSL</span>
                <span className="flex items-center gap-1.5 text-slate-700"><Truck className="h-4.5 w-4.5 text-blue-600" /> Envio Expresso em 24h</span>
                <span className="flex items-center gap-1.5 text-slate-700"><CreditCard className="h-4.5 w-4.5 text-amber-600" /> Pague só na Entrega</span>
              </div>
            </div>

            {/* Right Media - Original Product Image provided by user */}
            <div className="lg:col-span-5 relative flex justify-center">
              <div className="relative w-full max-w-md lg:max-w-none">
                <div className="absolute inset-0 bg-blue-100/40 rounded-3xl filter blur-xl" />
                <div className="relative border-4 border-slate-100 rounded-3xl overflow-hidden bg-white shadow-xl p-4">
                  <img 
                    src={IMAGES.original} 
                    alt="Óculos Inteligente 2V Pro Original" 
                    className="w-full h-auto object-contain mx-auto max-h-[350px] lg:max-h-none"
                  />
                  <div className="bg-slate-50 border border-slate-100 p-3.5 rounded-xl flex items-center gap-3 mt-4">
                    <div className="h-10 w-10 rounded-full bg-emerald-100 flex items-center justify-center shrink-0">
                      <ShieldCheck className="h-5 w-5 text-emerald-600" />
                    </div>
                    <div>
                      <h4 className="text-xs font-black text-slate-900 uppercase tracking-wider">PAGUE SOMENTE AO RECEBER!</h4>
                      <p className="text-2xs sm:text-xs text-slate-500 font-semibold leading-tight">Não precisa pagar nada agora pelo site. Faça o agendamento e pague apenas ao entregador!</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </header>

      {/* NEW SECTION: Protect your vision (Highly emotional, great for Google Ads & conversions) */}
      <section className="py-12 bg-amber-50/50 border-b border-slate-200">
        <div className="container max-w-5xl mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-10 space-y-2">
            <Badge className="bg-amber-100 text-amber-900 hover:bg-amber-100 border-none font-black py-1 px-3.5 text-xs uppercase rounded-full">
              🛡️ ATENÇÃO E PROTEÇÃO
            </Badge>
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-black text-slate-900 tracking-tight uppercase">
              PROTEJA O SEU BEM MAIS PRECIOSO, A SUA VISÃO!
            </h2>
            <p className="text-slate-600 text-sm sm:text-base font-medium">
              O Óculos Inteligente 2V Pro foi desenvolvido com lentes de altíssima tecnologia para garantir conforto, proteção e nitidez imediata para os seus olhos.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
            {/* Left: User-provided physical demo GIF showing extreme flexibility and strength */}
            <div className="md:col-span-6 flex justify-center">
              <div className="relative border border-slate-200 rounded-2xl overflow-hidden bg-white shadow-md p-2 max-w-sm">
                <img 
                  src={IMAGES.physical_demo} 
                  alt="Flexibilidade e Resistência do Óculos Inteligente" 
                  className="w-full h-auto rounded-xl aspect-[4/3] object-cover"
                />
                <div className="p-3 text-center bg-slate-50 rounded-lg mt-2">
                  <p className="text-xs sm:text-sm text-slate-700 font-black">
                    Flexibilidade incrível: Armação super resistente que não quebra!
                  </p>
                </div>
              </div>
            </div>

            {/* Right: Key features explaining protection */}
            <div className="md:col-span-6 space-y-4">
              <h3 className="text-xl sm:text-2xl font-bold text-slate-900">
                Por que o Óculos 2V Pro é a melhor escolha?
              </h3>
              <p className="text-slate-600 text-sm sm:text-base font-medium">
                Diferente dos óculos comuns que pesam no rosto e cansam a vista, a armação do 2V Pro é feita de liga ultraleve e flexível que não aperta as têmporas nem o nariz.
              </p>

              <div className="space-y-3 pt-2">
                {[
                  { title: "Lentes com Filtro de Luz Azul", desc: "Protege seus olhos contra a luz prejudicial de celulares, computadores e televisões, reduzindo a fadiga e dores de cabeça." },
                  { title: "Resistência Extrema a Impactos", desc: "Lentes e armação altamente resistentes a quedas, riscos e torções do dia a dia." },
                  { title: "Adaptação Anatômica Confortável", desc: "Apoio nasal macio e hastes flexíveis que se ajustam sem marcar ou machucar a pele." }
                ].map((item, idx) => (
                  <div key={idx} className="flex gap-3">
                    <div className="h-6 w-6 rounded-full bg-blue-100 flex items-center justify-center shrink-0 mt-0.5">
                      <Check className="h-4 w-4 text-blue-600 font-black" />
                    </div>
                    <div>
                      <h4 className="font-bold text-sm sm:text-base text-slate-900">{item.title}</h4>
                      <p className="text-xs sm:text-sm text-slate-500 font-medium leading-relaxed">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* NEW SECTION: Drive Safely comparison (highly convincing visual argument) */}
      <section className="py-12 bg-white border-b border-slate-200">
        <div className="container max-w-5xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
            
            {/* Left: Text explaining driving benefits */}
            <div className="md:col-span-6 space-y-4 order-2 md:order-1">
              <Badge className="bg-emerald-100 text-emerald-800 hover:bg-emerald-100 border-none font-extrabold py-1 px-3 text-xs uppercase">
                🚗 DIREÇÃO SEGURA
              </Badge>
              <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
                Volte a dirigir com total segurança e clareza!
              </h2>
              <p className="text-slate-600 text-sm sm:text-base font-medium leading-relaxed">
                Dirigir à noite ou sob sol forte pode ser um grande desafio quando a visão começa a falhar. O Óculos Inteligente 2V Pro ajuda a reduzir o ofuscamento causado pelos faróis dos carros em sentido contrário e melhora o contraste da pista.
              </p>

              <div className="space-y-3 pt-2">
                {[
                  { title: "Redução de Reflexos Noturnos", desc: "Ameniza aquele brilho estourado dos faróis e postes de iluminação pública à noite." },
                  { title: "Melhor Contraste sob Sol Forte", desc: "Melhora a definição de obstáculos, placas e pedestres na via durante o dia." },
                  { title: "Foco Rápido Painel / Pista", desc: "Olhe para o velocímetro do carro e volte a focar na estrada instantaneamente e sem esforço." }
                ].map((item, idx) => (
                  <div key={idx} className="flex gap-3">
                    <div className="h-6 w-6 rounded-full bg-emerald-100 flex items-center justify-center shrink-0 mt-0.5">
                      <Check className="h-4 w-4 text-emerald-600 font-black" />
                    </div>
                    <div>
                      <h4 className="font-bold text-sm sm:text-base text-slate-900">{item.title}</h4>
                      <p className="text-xs sm:text-sm text-slate-500 font-medium leading-relaxed">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Right: Driving comparison image provided by user */}
            <div className="md:col-span-6 flex justify-center order-1 md:order-2">
              <div className="relative border border-slate-200 rounded-2xl overflow-hidden bg-white shadow-md p-2 max-w-sm">
                <img 
                  src={IMAGES.driving_compare} 
                  alt="Comparativo de Direção Antes e Depois" 
                  className="w-full h-auto rounded-xl"
                />
                <div className="p-3 text-center bg-slate-50 rounded-lg mt-2">
                  <p className="text-xs sm:text-sm text-slate-700 font-black">
                    Enxergue placas e obstáculos com nitidez e segurança!
                  </p>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* Video Demonstration Section - EXPOSED layout (No selectors, all 4 videos side by side / grid) */}
      <section className="py-12 bg-slate-50 border-b border-slate-200">
        <div className="container max-w-6xl mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-10 space-y-2">
            <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100 border-none font-extrabold py-1.5 px-4 text-xs uppercase rounded-full">
              🎬 VÍDEOS DE DEPOIMENTOS REAIS
            </Badge>
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-black text-slate-900 tracking-tight">
              Assista aos depoimentos de clientes reais!
            </h2>
            <p className="text-slate-600 text-sm sm:text-base font-medium">
              Não precisa selecionar! Abaixo estão expostos os 4 vídeos de depoimentos. Clique em qualquer um deles para assistir ao funcionamento do óculos!
            </p>
          </div>

          {/* Grid of all 4 videos exposed simultaneously */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {VIDEOS.map((video, idx) => (
              <div key={idx} className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm flex flex-col">
                <div className="relative aspect-video bg-slate-950 group">
                  <video
                    src={video.url}
                    className="w-full h-full object-contain"
                    loop
                    muted={mutedVideos[idx]}
                    playsInline
                    controls
                  />
                  
                  {mutedVideos[idx] && (
                    <button 
                      onClick={() => toggleMuteVideo(idx)}
                      className="absolute top-3 right-3 bg-slate-900/80 backdrop-blur-sm border border-slate-700/50 text-white p-2 rounded-full hover:bg-slate-800 transition-colors"
                    >
                      <VolumeX className="h-4 w-4" />
                    </button>
                  )}
                  
                  {!mutedVideos[idx] && (
                    <button 
                      onClick={() => toggleMuteVideo(idx)}
                      className="absolute top-3 right-3 bg-blue-600 text-white p-2 rounded-full hover:bg-blue-700 transition-colors"
                    >
                      <Volume2 className="h-4 w-4" />
                    </button>
                  )}
                </div>
                
                <div className="p-4 flex-grow flex flex-col justify-between space-y-2">
                  <div>
                    <h4 className="font-black text-slate-900 text-sm sm:text-base">{video.title}</h4>
                    <p className="text-xs text-slate-500 font-semibold mt-0.5">{video.desc}</p>
                  </div>
                  <div className="flex items-center gap-1 text-amber-500 text-xs pt-1">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="h-3 w-3 fill-current" />
                    ))}
                    <span className="text-slate-700 font-bold ml-1">5.0</span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center pt-10">
            <Button 
              onClick={scrollToOffers}
              className="bg-emerald-600 hover:bg-emerald-700 text-white font-black py-5 px-10 rounded-xl text-base sm:text-lg shadow-md shadow-emerald-600/10 uppercase"
            >
              AGENDAR MEU PEDIDO AGORA
            </Button>
          </div>
        </div>
      </section>

      {/* Fit Checklist - Simplistic and direct for Google Ads compliance */}
      <section className="py-12 bg-white">
        <div className="container max-w-5xl mx-auto px-4">
          <div className="max-w-3xl mx-auto space-y-6">
            <div className="space-y-2 text-center">
              <Badge className="bg-emerald-100 text-emerald-800 hover:bg-emerald-100 border-none font-extrabold py-1 px-3 text-xs uppercase">
                ✔ SERVE PARA VOCÊ?
              </Badge>
              <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
                Para quem é recomendado o Óculos Inteligente?
              </h2>
              <p className="text-slate-600 text-sm sm:text-base font-medium">
                Veja as principais indicações do Óculos Inteligente 2V Pro para o seu dia a dia:
              </p>
            </div>

            {/* Grid of fits */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {[
                { title: "Miopia leve ou moderada", desc: "Ajuda a enxergar objetos e placas de trânsito distantes com clareza." },
                { title: "Hipermetropia", desc: "Facilita a leitura de livros e visualização de objetos bem de perto." },
                { title: "Vista cansada (presbiopia)", desc: "Ideal para ler mensagens no celular ou no computador sem forçar os olhos." },
                { title: "Modelo único e unissex", desc: "Design moderno que se adapta anatomicamente a qualquer formato de rosto." }
              ].map((item, idx) => (
                <div key={idx} className="bg-slate-50 border border-slate-200 p-4 rounded-xl space-y-1">
                  <div className="flex items-center gap-2">
                    <div className="h-6 w-6 rounded-full bg-emerald-100 flex items-center justify-center shrink-0">
                      <Check className="h-4 w-4 text-emerald-600 font-black" />
                    </div>
                    <h4 className="font-bold text-sm sm:text-base text-slate-900">{item.title}</h4>
                  </div>
                  <p className="text-xs sm:text-sm text-slate-500 font-medium pl-8 leading-relaxed">{item.desc}</p>
                </div>
              ))}
            </div>

            {/* Google Ads Compliance Box - Very clear and non-misleading */}
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-4.5 space-y-3">
              <div className="flex items-center gap-2 text-amber-800 font-bold text-sm sm:text-base">
                <AlertTriangle className="h-5 w-5 text-amber-600 shrink-0" />
                <span>INFORMAÇÕES IMPORTANTES DE SAÚDE</span>
              </div>
              <div className="space-y-2 text-xs sm:text-sm text-amber-900 leading-relaxed pl-7 font-medium">
                <p>
                  ✔ <strong>Não precisa de receita médica:</strong> O óculos utiliza tecnologia de foco flexível e dinâmico, pronto para uso imediato.
                </p>
                <p>
                  👉 <strong>Para até +3.50 de grau:</strong> Funciona muito bem e resolve cerca de <strong>90% dos casos</strong> comuns de fadiga visual e dificuldade de foco.
                </p>
                <p>
                  ⚠️ <strong>Não indicado para astigmatismo alto ou grau acima de +4.00:</strong> Se você possui astigmatismo elevado, recomendamos lentes de grau tradicionais feitas sob medida.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* COD Process - Extremely clear and easy to understand for seniors */}
      <section className="py-12 bg-slate-900 text-white relative overflow-hidden">
        <div className="container max-w-5xl mx-auto px-4 relative z-10">
          
          <div className="text-center max-w-3xl mx-auto mb-10 space-y-2">
            <Badge className="bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-bold py-1 px-3 text-xs uppercase rounded-full">
              🚚 COMPRA 100% SEGURA
            </Badge>
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-black text-white tracking-tight">
              Como funciona o pagamento na entrega?
            </h2>
            <p className="text-slate-300 text-sm sm:text-base font-medium">
              Você não precisa pagar nada agora! O agendamento é feito de forma rápida e segura.
            </p>
          </div>

          {/* Steps */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            {[
              {
                step: "1",
                title: "Agende o Pedido",
                desc: "Escolha o kit ideal de óculos abaixo e preencha seus dados de entrega."
              },
              {
                step: "2",
                title: "Envio Imediato",
                desc: "O produto é enviado no dia seguinte diretamente para o seu endereço."
              },
              {
                step: "3",
                title: "Receba em Casa",
                desc: "O entregador leva o pacote lacrado e seguro até você."
              },
              {
                step: "4",
                title: "Pague ao Receber",
                desc: "Você só paga quando estiver com o óculos na mão! Aceitamos PIX, dinheiro ou cartão."
              }
            ].map((step, idx) => (
              <div key={idx} className="bg-slate-800/80 border border-slate-700 p-5 rounded-xl space-y-2">
                <div className="h-9 w-9 rounded-full bg-emerald-500 text-slate-950 font-black text-base flex items-center justify-center shadow-md">
                  {step.step}
                </div>
                <h3 className="font-bold text-base sm:text-lg text-white">{step.title}</h3>
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-medium">{step.desc}</p>
              </div>
            ))}
          </div>

          {/* COD Benefits */}
          <div className="mt-8 grid grid-cols-1 sm:grid-cols-3 gap-4 text-center">
            {[
              { title: "Sem Pagamento Antecipado", desc: "Risco zero! Seu dinheiro fica com você até o produto chegar." },
              { title: "Mais Segurança", desc: "Evite fraudes pagando apenas ao conferir a entrega." },
              { title: "Mais Tranquilidade", desc: "Acompanhe todo o trajeto do seu pedido pelo WhatsApp." }
            ].map((item, idx) => (
              <div key={idx} className="bg-slate-950/50 border border-slate-800 p-4 rounded-xl space-y-1">
                <h4 className="font-bold text-sm sm:text-base text-emerald-400">{item.title}</h4>
                <p className="text-xs sm:text-sm text-slate-300 font-medium leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>

          {/* Warning */}
          <div className="mt-8 bg-amber-400/10 border border-amber-400/20 rounded-xl p-5 space-y-2">
            <div className="flex items-center gap-2 text-amber-400 font-bold text-sm sm:text-base">
              <AlertTriangle className="h-5 w-5 shrink-0" />
              <span>AVISO IMPORTANTE:</span>
            </div>
            <ul className="list-disc list-inside text-xs sm:text-sm text-slate-200 space-y-1.5 pl-2 font-medium">
              <li>Agende a entrega para um dia em que tenha alguém em casa para receber e efetuar o pagamento.</li>
              <li>No dia da entrega, o entregador entrará em contato via ligação ou <strong>WhatsApp</strong>.</li>
              <li>Fique atento às notificações no seu celular para não perder a entrega.</li>
            </ul>
          </div>

        </div>
      </section>

      {/* Offers Section - Large pricing, GREEN buttons, original product image */}
      <section ref={offersSectionRef} className="py-16 bg-white relative scroll-mt-16">
        <div className="container max-w-6xl mx-auto px-4">
          
          <div className="text-center max-w-3xl mx-auto mb-12 space-y-2">
            <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100 border-none font-extrabold py-1.5 px-4 text-xs uppercase rounded-full">
              🏷️ ESCOLHA A MELHOR OPÇÃO ABAIXO
            </Badge>
            <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
              Agende seu pedido com Desconto + Frete Grátis!
            </h2>
            <p className="text-slate-600 text-sm sm:text-base font-medium">
              Escolha a quantidade ideal para você e sua família. O preço promocional fica disponível somente hoje!
            </p>
          </div>

          {/* Offer Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-stretch">
            {OFFERS.map((offer) => (
              <Card 
                key={offer.id}
                className={`flex flex-col justify-between rounded-2xl transition-all duration-200 relative ${
                  offer.popular 
                    ? "border-4 border-emerald-500 bg-emerald-50/5 shadow-xl md:-translate-y-4 scale-100 md:scale-[1.03]" 
                    : "border-2 border-slate-200 hover:border-slate-300 bg-white shadow-sm"
                }`}
              >
                {/* Popular Badge */}
                {offer.popular && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-emerald-600 text-white text-xs font-black px-5 py-1.5 rounded-full tracking-wider shadow-md uppercase">
                    ⭐ MAIS VENDIDO (RECOMENDADO) ⭐
                  </div>
                )}

                {!offer.popular && (
                  <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 bg-slate-100 text-slate-700 border border-slate-200 text-xs font-bold px-4 py-1 rounded-full tracking-wider uppercase">
                    {offer.badge}
                  </div>
                )}

                <div>
                  <CardHeader className="pt-8 pb-4 text-center">
                    <CardTitle className="text-2xl sm:text-3xl font-black text-slate-900">{offer.title}</CardTitle>
                    <CardDescription className="text-sm text-slate-500 font-bold mt-1">{offer.subtitle}</CardDescription>
                    
                    <div className="mt-3 inline-block mx-auto">
                      <Badge className="bg-emerald-100 text-emerald-800 hover:bg-emerald-100 border-none font-black text-xs sm:text-sm py-1 px-3.5 rounded-md">
                        {offer.discount}
                      </Badge>
                    </div>
                  </CardHeader>

                  {/* Image of the product in each card */}
                  <div className="px-6 py-2 flex justify-center">
                    <img 
                      src={IMAGES.original} 
                      alt="Óculos Inteligente" 
                      className="h-28 w-auto object-contain"
                    />
                  </div>

                  <CardContent className="px-6 py-4 border-t border-b border-slate-100 bg-slate-50/50">
                    <div className="text-center space-y-1">
                      <p className="text-xs text-slate-400 line-through font-bold">De R$ {offer.id === "1-unit" ? "269,90" : offer.id === "2-units" ? "479,90" : "859,90"}</p>
                      <p className="text-4xl sm:text-5xl font-black text-slate-900 tracking-tight">{offer.price}</p>
                      <p className="text-sm font-bold text-slate-500">{offer.installment}</p>
                      <p className="text-xs text-emerald-600 font-black uppercase tracking-wider mt-1.5 flex items-center justify-center gap-1">
                        🚚 FRETE GRÁTIS + PAGAMENTO NA ENTREGA
                      </p>
                    </div>
                  </CardContent>

                  <CardContent className="p-6">
                    <ul className="space-y-3">
                      {offer.features.map((feat, i) => (
                        <li key={i} className="flex items-start gap-2.5 text-sm text-slate-700 font-bold leading-tight">
                          <div className="h-5 w-5 rounded-full bg-emerald-100 flex items-center justify-center shrink-0 mt-0.5">
                            <Check className="h-3 w-3 text-emerald-600 font-black" />
                          </div>
                          <span>{feat}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </div>

                <CardFooter className="p-6 pt-0">
                  <a 
                    href={offer.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full"
                  >
                    <Button 
                      className="w-full py-7 rounded-xl font-black text-lg sm:text-xl tracking-wide transition-all active:scale-[0.97] shadow-md bg-emerald-600 hover:bg-emerald-700 text-white shadow-emerald-600/10 uppercase"
                    >
                      AGENDAR PEDIDO
                    </Button>
                  </a>
                </CardFooter>
              </Card>
            ))}
          </div>

          {/* Satisfaction guarantee - Compliance */}
          <div className="mt-12 max-w-4xl mx-auto border border-slate-200 bg-slate-50/50 rounded-2xl p-6 md:p-8 grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
            <div className="md:col-span-3 flex justify-center">
              <div className="h-20 w-24 rounded-full bg-blue-100 flex items-center justify-center shrink-0">
                <ShieldCheck className="h-12 w-12 text-blue-600" />
              </div>
            </div>
            <div className="md:col-span-9 space-y-2 text-center md:text-left">
              <h3 className="font-black text-lg sm:text-xl text-slate-900">Satisfação Garantida ou seu Dinheiro de Volta!</h3>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed font-medium">
                Se por algum motivo achar que o produto não é para você, basta cancelar a compra e devolveremos todo o valor pago por você, sem perguntas e sem burocracia! Garantimos sua entrega com segurança e total conformidade.
              </p>
            </div>
          </div>

        </div>
      </section>

      {/* Customer Reviews - Social Proof */}
      <section className="py-12 bg-slate-50 border-t border-slate-200">
        <div className="container max-w-4xl mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-10 space-y-2">
            <Badge className="bg-emerald-100 text-emerald-800 hover:bg-emerald-100 border-none font-extrabold py-1 px-3 text-xs uppercase">
              ⭐ QUEM COMPROU, APROVOU!
            </Badge>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
              Veja depoimentos reais de quem já usa
            </h2>
            <p className="text-slate-600 text-sm sm:text-base font-medium">
              Entrega rápida com pagamento somente na entrega. Veja o que clientes reais estão dizendo.
            </p>
          </div>

          {/* Review Cards */}
          <div className="space-y-4">
            {TESTIMONIALS.map((review, idx) => (
              <div key={idx} className="bg-white border border-slate-200 p-5 rounded-xl shadow-2xs space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-full bg-slate-100 flex items-center justify-center font-bold text-slate-700 text-sm border border-slate-200">
                      {review.name.substring(0, 2)}
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <h4 className="font-bold text-sm sm:text-base text-slate-900">{review.name}</h4>
                        <span className="text-slate-400 text-xs">•</span>
                        <span className="text-slate-500 text-xs sm:text-sm font-bold">{review.location}</span>
                      </div>
                      <div className="flex items-center gap-1.5 mt-0.5">
                        <div className="flex text-amber-500">
                          {[...Array(5)].map((_, i) => (
                            <Star key={i} className="h-3 w-3 fill-current" />
                          ))}
                        </div>
                        <Badge className="bg-emerald-50 text-emerald-700 hover:bg-emerald-50 border border-emerald-100 text-3xs font-black py-0 px-1.5 rounded-sm">
                          {review.verified}
                        </Badge>
                      </div>
                    </div>
                  </div>
                  <span className="text-slate-400 text-xs">{review.time}</span>
                </div>

                <p className="text-xs sm:text-sm text-slate-700 leading-relaxed pl-0 sm:pl-13 font-medium">
                  "{review.text}"
                </p>

                <div className="flex items-center gap-2 pl-0 sm:pl-13 text-slate-500 text-xs">
                  <button className="flex items-center gap-1 hover:text-blue-600 font-bold transition-colors">
                    <ThumbsUp className="h-3.5 w-3.5" /> Útil ({review.likes})
                  </button>
                  <span>•</span>
                  <span className="text-slate-400">Responder</span>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center pt-8">
            <Button 
              onClick={scrollToOffers}
              className="bg-emerald-600 hover:bg-emerald-700 text-white font-black py-5 px-10 rounded-xl text-base sm:text-lg uppercase"
            >
              AGENDAR PEDIDO COM FRETE GRÁTIS
            </Button>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-12 bg-white border-t border-slate-200">
        <div className="container max-w-3xl mx-auto px-4">
          <div className="text-center mb-8 space-y-2">
            <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100 border-none font-extrabold py-1 px-3 text-xs uppercase">
              ❓ DÚVIDAS FREQUENTES
            </Badge>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
              Perguntas Frequentes
            </h2>
            <p className="text-slate-600 text-sm sm:text-base font-medium">
              Tem alguma dúvida? Encontre a resposta rápida aqui.
            </p>
          </div>

          <Accordion type="single" collapsible className="w-full space-y-3">
            {[
              {
                q: "Quanto custa o frete?",
                a: "Frete 100% GRÁTIS para todo o Brasil! Você não paga nada a mais pela entrega. É só escolher o melhor dia pra receber e pronto."
              },
              {
                q: "Como vou receber o produto?",
                a: "A entrega é feita por transportadoras parceiras diretamente no seu endereço. Você escolhe a data e nós agendamos a entrega de acordo com a sua preferência."
              },
              {
                q: "⏱️ Em quanto tempo recebo meu pedido?",
                a: "A entrega é feita em até 24 horas úteis para capitais e regiões metropolitanas, mas você escolhe a data no momento da compra. A gente se adapta à sua agenda."
              },
              {
                q: "Quais dados preciso informar?",
                a: "Apenas o essencial para entrega e faturamento fiscal: nome completo, endereço de entrega completo e telefone com WhatsApp para confirmar a entrega."
              },
              {
                q: "Como funciona o pagamento na entrega?",
                a: "Você agenda seu pedido normalmente pelo site, sem pagar nada adiantado. O produto é enviado e você só paga quando receber o óculos em mãos! O pagamento pode ser feito em dinheiro, PIX ou cartão (dividido em até 12x)."
              }
            ].map((faq, idx) => (
              <AccordionItem 
                key={idx} 
                value={`faq-${idx}`}
                className="border border-slate-200 rounded-xl px-4 bg-slate-50/50 hover:bg-slate-50 transition-colors"
              >
                <AccordionTrigger className="font-black text-sm sm:text-base text-slate-900 py-4 hover:no-underline text-left">
                  {faq.q}
                </AccordionTrigger>
                <AccordionContent className="text-xs sm:text-sm text-slate-600 leading-relaxed pb-4 font-medium">
                  {faq.a}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </section>

      {/* Footer with Compliance links (Terms and Privacy) */}
      <footer className="bg-slate-950 text-slate-400 py-12 border-t border-slate-900 text-sm sm:text-base">
        <div className="container max-w-6xl mx-auto px-4 space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-center text-center md:text-left">
            <div className="space-y-2">
              <h3 className="text-white font-black text-lg tracking-wider">ÓCULOS 2V PRO®</h3>
              <p className="text-xs text-slate-500 font-medium">Enxergue perfeitamente de perto e de longe sem trocar de óculos.</p>
            </div>
            
            {/* COMPLIANCE LINKS: Essential for Google Ads approval */}
            <div className="flex justify-center gap-6 text-xs sm:text-sm font-bold">
              <Link href="/termos" className="hover:text-white transition-colors">Termos de Uso</Link>
              <Link href="/privacidade" className="hover:text-white transition-colors">Políticas de Privacidade</Link>
              <a href="#" className="hover:text-white transition-colors">Formas de Pagamento</a>
            </div>
            
            <div className="flex flex-col items-center md:items-end gap-2 text-xs">
              <span className="flex items-center gap-1 text-emerald-400 font-bold">
                <ShieldCheck className="h-4.5 w-4.5" /> AMBIENTE SEGURO SSL
              </span>
              <p className="text-slate-500 text-3xs font-medium">CNPJ: 37.273.558/0001-50</p>
            </div>
          </div>

          <div className="border-t border-slate-900 pt-6 text-center text-3xs sm:text-2xs text-slate-600 space-y-2 font-medium">
            <p>© 2025 / 2026 ÓCULOS 2V PRO®. Todos os direitos reservados.</p>
            <p className="max-w-2xl mx-auto leading-relaxed">
              Isenção de responsabilidade: Este produto é um auxílio óptico adaptável para foco dinâmico. Ele não substitui exames oftalmológicos clínicos de rotina. Consulte regularmente o seu oftalmologista.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
